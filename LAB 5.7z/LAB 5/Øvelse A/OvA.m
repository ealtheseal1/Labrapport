%%lab 5 ovelse A

%Registrert m�lingsdata

A = [0 30 60 75 90 120]; %sekunder, tid
A2 = [0 30 60 90 120 270 300];

%%M�ling begge i is%%
B = [0.060 0.027 0.014 0.013 0.011 0.01]; %spenning mV
B2 = [0.060 0.040 0.034 0.026 0.016 0.007 0.005]; % mAling 2, mV


%%M�ling ene i is og andre p� ALU%%
A3 = [0 30 60 90 120 150 180 240]; % tid [s]
B3 = [0.832 0.834 0.835 0.834 0.835 0.833 0.834 0.838]; %spennning mV

%%Motstand termistor ALU ALU og temp IS og ALU%%

termistor1 = [116.3e03] %motstand
termistor2 = [115.9e03] %motstand 
A4 = [0.831]








%Plottere
figure(1)
plot(A,B)
hold('on')
plot (A2,B2)
xlabel('Tid, [s]')
ylabel('Spenning, [mV]')
legend('Maling begge i is')

figure(2)
plot (A3,B3)
xlabel('Tid, [s]')
ylabel('Spenning, [mV]')
legend('Maling en i is og en p� ALU')

%h = fittype('alpha*x + beta');
%[fit1,gof,fitinfo] = fit(A2,B2,h,'StartPoint',[0 0]);
%residuals = fitinfo.residuals;
%I = abs( residuals) > 1.5 * std( residuals );
%outliers = excludedata(A2,B2,'indices',I);

%fit2 = fit(A2,B2,h,'StartPoint',[0 0],...
           %'Exclude',outliers)



Xi = [0.002 0.029 0.089 0.169]; %m
load('CIS.mat' , 't')
load('CIS.mat', 'T')
figure(3)
plot(Xi(4)./sqrt(4.*t), T(:,1), 'o')
hold('on')
plot(Xi(3)./sqrt(4.*t), T(:,2), 'o')
plot(Xi(2)./sqrt(4.*t), T(:,3), 'o')
plot(Xi(1)./sqrt(4.*t), T(:,4), 'o')
%eta = Xi(1)./sqrt(4.*t);

xlabel('\eta')
ylabel('T. [C]')



