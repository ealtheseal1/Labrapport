function T = termistortemp(R)
a = 8.42e-004; 
b = 2.068e-004; 
c = 8.591e-008; 
R0 = 1; 

Tmidl = 1./(a + b.*log(R./R0) + c.*log(R./R0).^3); 
T = (Tmidl) - 273.16;

end

