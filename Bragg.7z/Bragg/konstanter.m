planck = 6.63*10^-34;
planck_h = 1.05457*10^-34;
lyshast = 2.99792*10^8;
epsnull = 8.85419*10^-12; %vakuum permitivitet
masse_e = 9.10938*10^-31; % masse elektron
masse_p = 1836.0*masse_e; %masse proton ,Hydrogen
masse_n = 1.675*10^-27; %masse n�ytron
masse_HG  = 200*masse_p; %masse kvikks�lv
elek_ladn = -1.60218*10^-19;%element�r ladning
k_e =  1./(4*pi*epsnull); %coloumb konstant, ELMAG
mu = (masse_e*masse_p)./(masse_e+masse_p); %massesenter 
RH = 1.0967757*10^7; %Ryderg constant
RH_mu = (mu*elek_ladn.^4)./(8*epsnull.^2*planck.^3*lyshast); %Rydberg justert massesenter
u = 1.66539040*10^-27; %atomic mass u


n = 1; %tilstand stasjon�r

a_0 = planck_h.^2./(mu*k_e*elek_ladn.^2);%Bohrradien, m_e erstattet med mu
a0 = planck_h.^2./(masse_e*k_e*elek_ladn.^2); %Bohrradien m_e
r_n = a_0*n.^2; %radius
r_nme = a0*n.^2; %radius with me

Ebohr = ((-k_e.^2*mu*elek_ladn.^4)/(2*planck_h.^2))*(1/n.^2); %Energi potensial, hydrogen
Ebohr_me  = ((-k_e.^2*masse_e*elek_ladn.^4)/(2*planck_h.^2))*(1/n.^2); %E potensial, ikke massesenter justert

ni = 3; %Balmer 
Balmer = (3645.6*10^-10)*(ni.^2/(ni.^2-4)); %Balmer serien
Rydbergjuster = (RH_mu*(1./4- 1./(ni.^2)));%1/lambda with mu instead of m_e
Rydbergjustert = (Rydbergjuster).^-1;


nm = 1.0*10.^-9;
X = [lyshast/(2.536*nm) lyshast/(3.132*nm) lyshast/(3.650*nm) lyshast/(4.047*nm)];
Y = [1.95*elek_ladn 0.98*elek_ladn 0.5*elek_ladn 0.14*elek_ladn];
%A = polyfit(X,Y,1);
%w0 = polyval(A,20);

K = -1:6;
N = 1:length(K);
V0 = -13.6*elek_ladn;

%potensial = V0*((k_e.^2 * elek_ladn.^4 * masse_e)./(2 * planck_h.^2 * N.^2)).^K;

%prelab oppg 4

%maling = [130 124 133 131 128 132 138 192 244 301 348 403 462 508];
%gitter = 401; %pm

%degrees = 180/pi;
%findangle = asin(maling./gitter).*degrees;
%plot(linspace(14,25,14),findangle)
%xlabel('n_{\theta}');
%ylabel('\theta')
%minimumangle = min(findangle);
%legend(strcat('minimum \theta \approx', num2str(minimumangle)));
%elek_ladn = abs(elek_ladn);

%Potensialprelab = (masse_e*c^2*elek_ladn^-1)/sqrt(1-(minimumangle/c)^2) - masse_p*c^2/elek_ladn

%load diameter.dat

%antall = length(diameter);

%lambdacompton = planck/(masse_e*c);
%spenningen = diameter(:,[1]);

%lambda = lambdacompton*sqrt((masse_e*c^2)/2*elek_ladn*spenningen).*relfaktor([spenningen]);

%phi = 1/antall*sum(lambda./diameter(:,[2]));
%stdphi = std(lambda/diameter(:,[2]));

%combination of error
%LLL = 140.0*10^-3;
%phiphi = 8.31*10^-10;
%ddd = 2*LLL*phiphi;
%deltaddd = ( (0.08/8.31)^2 + (3.0/127)^2 ) * ddd^2;
%deltadd = sqrt(deltaddd);

%forholdet = deltadd/ddd


