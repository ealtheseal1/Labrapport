%lab Bragg
konstanter; %importing constants
usikkerhet; %statistisk analyse av datasett

%Oppg A LiF- krystall

grader = 12:0.5:22;
feilmaling = [299 269 225 247 296 308 338 282 297 297 295 290 341 348 345 389 355 393 403 451 421 405]; %intensitet, Gauge-muller
maling = [121 105 104 97 109 107 115 154 180 210 262 327 353 425 499 523 652 673 687 758 733];

gitter = 401; %pm
degrees = 180/pi; %rad to deg
findangle = asin(maling./gitter).*degrees;

A = polyfit(grader(8:end),maling(8:end),1);
stigningstall=A(1);
konstantledd=A(2);
yline = polyval(A,grader(8:end));
rettstrek = ones(length(grader))*110;

figure(1)
plot (grader,maling, 'o')
hold on
plot (grader(1:8),rettstrek(1:8), 'b')
hold on
plot(grader(8:end),yline,'r')
xlabel('2_{\theta}');
ylabel('Intensitet')
minimumangle = grader(8:end-13);
legend(strcat('min 2\nu \approx', num2str(minimumangle)),strcat( 'Ax + B:' ,num2str(A)));




%punkt 3 finn spenningen over r�ntgenr�ret

%PotensialRONTGENROR = (masse_e*c^2/elek_ladn)/sqrt(1-(minimumangle/c)^2) - (masse_e*c^2/elek_ladn);


%Oppgave B RbCl -krystall

K_alfa1 = 154.4;
K_alfa2 = 154;
forventetalfa = (K_alfa1+K_alfa2)/2; %picometer

K_beta1 = 139.2;
K_beta2 = 138.1;
forventetbeta = (K_beta1 + K_beta2)/2; %picometer

gitteroppgB = 655; %pm

forventetvinkelalfa = asin(forventetalfa/gitteroppgB)*degrees;
forventetvinkelbeta = asin(forventetbeta/gitteroppgB)*degrees;
GM1ordenALFA = forventetvinkelalfa*2;
GM1ordenBETA = forventetvinkelbeta*2; %pga 2 theta

GM2ordenALFA = asin(2*forventetalfa/gitteroppgB)*degrees*2;
GM2ordenBETA = asin(2*forventetbeta/gitteroppgB)*degrees*2;

%text = ('Vi forventer folgende \theta_{\alfa}' , num2str(forventetvinkelalfa) )
%text2 = ('Vi forventer folgende \theta_{\beta}' , num2str(forventetvinkelbeta) )

thetaforBetaalfa = [21.5 22 22.5 23 23.5 24 24.25 24.5 24.75 25 25.5 26 26.5 27 27.25 27.5 27.75 28 28.5 29];
intensitetBetaalfa = [108 125 131 225 342 426 497 465 389 307 382 1223 1764 2075 1874 1314 820 290 128 123];

thetaforBA2 = [48 48.5 49 49.5 50 50.25 50.5 51 51.5 52 53 54 54.25 54.5 54.75 55 55.25 55.5 55.75 56]; 
intensitetBA2 = [68 74 117 166 166 150 121 62 71 55 64 96  160 264 397 590 645 703 691 517];

figure(2)
plot(thetaforBetaalfa,intensitetBetaalfa,'b')
legend('n_{1} \cdot \lambda')
xlabel('2\nu')
ylabel('Intensitet')
hold on
%figure(3)
scatter(thetaforBA2,intensitetBA2, 'r')
xlabel('2\nu')
ylabel('Intensitet')
legend('n_{2} \cdot \lambda')
%text(55.5,max(thetaforBA2),'\alpha_1')

%relativ differanse mellom forventet og faktiske signaturer
Alfa1ordendiff = max(thetaforBetaalfa)/GM1ordenALFA
Alfa2ordendiff = max(thetaforBA2)/GM2ordenALFA


%oppgave C Elektrondiffraksjon
mostand = 10*10^9; %Ohm

spenning = [6 6.2 6.4 6.6 6.8 7.0 7.2 7.4 7.6 7.8 8.0]*1000; %V
diameterindrelille = [1.89 1.9 1.87 1.89 1.82 1.77 1.74 1.70 1.66 1.69 1.65]*10;
diameterytrelille = [2.33  2.29 2.10 2.20 2.05 2.11 2.11 1.99 2.0 1.92 1.85]*10;
diameterindrestore = [3.46 3.30 3.36 3.19 3.28 3.07 3.14 3.05 2.96 3.03 2.90]*10; %mm
diameterytrestore = [3.82 3.82 3.7 3.55 3.55 3.55 3.55 3.50 3.44 3.43 3.35]*10;

relfaktor([spenning]);

figure(4)
plot(spenning,diameterindrelille, 'r')
hold on
plot(spenning , diameterindrestore, 'b')
hold on
plot(spenning, diameterytrelille, 'p')
hold on
plot(spenning, diameterytrestore,'g')
xlabel('Spenning, U [V]')
ylabel('Diameter, [mm]')
legend()


%Finne gitter elektrondiffraksjon
lambdacompt = 2.426*10^-12;
L =127.3/1000; %m
L2 = 126.7/1000; %m-1
Diameter = [diameterindrelille + diameterindrestore]*0.5*1/1000; %<D> in meter
Diameter2 = [diameterytrelille + diameterytrestore]*0.5*1/1000

fOrstedel = (lambdacompt *2*L)./Diameter2;
andredel = sqrt((masse_e*lyshast^2)./(2*abs(elek_ladn)*spenning));
sistedel = relfaktor([spenning]);

gitterkonstavU = fOrstedel.*andredel.*sistedel*10^12 %pm

relellerikkerel = [6 6.2 6.4 6.6 6.8 7 7.2 7.4 7.6 7.8 8]*1000;
relfaktor([relellerikkerel])