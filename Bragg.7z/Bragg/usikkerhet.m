%statistiske tolkninger av datasett

grader = 12:0.5:22;
maling = [121 105 104 97 109 107 115 154 180 210 262 327 353 425 499 523 652 673 687 758 733];
A = polyfit(grader(8:end),maling(8:end),1)

m=A(1)
c=A(2)

x = grader(8:end);
y = maling(8:end);

D = sum(x.^2) - 1/length(x) *(sum(x)).^2;
d = y - m*x - c;

deltaMkvadr = 1/(length(y)-2) * sum(d.^2)./D;

deltaM = sqrt(deltaMkvadr)

deltaCkvadr = 1/(length(x)-2) * (D/length(x) + mean(x))* sum(d.^2)/D;

deltaC = sqrt(deltaCkvadr)