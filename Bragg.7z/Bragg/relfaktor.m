 function [funksjon] = relfaktor(U)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
masse_e = 9.10938*10^-31; % masse elektron
lyshast = 2.99792*10^8;
elek_ladn = -1.60218*10^-19;%element�r ladning
elek_ladn = abs(elek_ladn);

nevner = sqrt( 1 + (elek_ladn*U./(2*masse_e*lyshast^2)));

funksjon = 1./(nevner)

%1 = A
%2 = A
%3 = D
%4 = B
%5 = C
%6 = B
%7 = C
%8 = B
%9 = B
%10 = A ble gjort p� ark


end

